<?php
//checked security k1
session_start();

if(isset($_POST['google_sign_submit']))
{ 
if(isset($_SESSION['email_third_party'])){
	

require_once("welcome.php");
require_once("imp/function.php");
/* Come From Form by Post Method */
$nameX=securedata($_POST['username']);
$emailX=securedata($_POST['useremail']);
$mobile_noX=securedata($_POST['usermobile_no']);
$passwordX=securedata($_POST['userpassword']);
$genderX=securedata($_POST['usergender']);
$dobX=securedata($_POST['userdob']);
$date_dob=securedata($_POST['date_dob']);
$month_dob=securedata($_POST['month_dob']);
$year_dob=securedata($_POST['year_dob']);
if($genderX=="male" || $genderX=="female"){
	$genderverify=1;
}else{
	$genderverify=0;
}

/* Validation */
if($genderverify==1)
{
if(preg_match('%^[A-Za-z\.\-\ ]{2,20}$%',stripslashes(trim($nameX))))
	{
		
		    if(preg_match('%^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$%',stripslashes(trim($emailX))))
	        {

		        if(preg_match('%^[0-9]{10}$%',stripslashes(trim($mobile_noX))))
	            {
				     if(!preg_match('%^[\'\"\<\>]%',stripslashes(trim($passwordX))))
	                 {
						$passwordX= encrypt_decrypt('encrypt', $passwordX);
				         $_SESSION['nameX']=$nameX;
				         $_SESSION['emailX']=$emailX;
				         $_SESSION['mobile_noX']=$emailX;
                         if(strlen($passwordX)>6 )
                         {   
                             $ip_address = mysqli_real_escape_string($con,$_SERVER['REMOTE_ADDR']);
                             $browser = mysqli_real_escape_string($con,$_SERVER['HTTP_USER_AGENT']);	
                             date_default_timezone_set('Asia/Calcutta');
                             $sign_up_time=date("h:i a");
                             $sign_up_year= date('Y');
                             $sign_up_month= date('m');
                             $sign_up_day= date('d');                             
                             $uid=md5(uniqid() . time());
							 /* For table */
                             $follower="follower".$uid;
                             $following="following".$uid;
                             $seenlist="seen".$uid;
                             $detaillist="fulldetail".$uid;
                             $couplelist="couple_sent_req".$uid;
                             $notificationlist="notify".$uid;
                             $couplerequest="couple_request".$uid;
                             $transaction="mytransaction".$uid;
							 $mymember="mymember".$uid;
						     require_once("welcome.php");
			                 $chkmember=mysqli_query($con,"select name from allmember where email='$emailX'");
			                    if(mysqli_num_rows($chkmember)==0)
			                    {
								   	 
						                
											           														
															   if(mysqli_query($con,"CREATE TABLE `$notificationlist` ( `s_no` INT(50)  AUTO_INCREMENT ,`notification` TEXT ,`notification_id` TEXT ,`open_status` INT(20) ,`seen_status` INT(20) ,`priority` INT(20) ,`browser` TEXT  ,`linkofinfo` TEXT  ,`from_person` TEXT  ,`referer` TEXT  ,`ip_address` TEXT  ,PRIMARY KEY (`s_no`)  ) ENGINE = InnoDB;"))
	                                                            {
			    											     	
																		if(mysqli_query($con,"CREATE TABLE `$transaction` ( `s_no` INT(50)  AUTO_INCREMENT , `name` TEXT  ,`email` TEXT  , `id` INT(50)  , `uid` TEXT , `amount` TEXT , `productinfo` TEXT , `transaction_id` TEXT , `payu_transaction_id` TEXT ,`browser` TEXT  ,`timing` TEXT  ,`day` TEXT  ,`month` TEXT  ,`year` TEXT  ,`referer` TEXT  ,`ip_address` TEXT  ,PRIMARY KEY (`s_no`)  ) ENGINE = InnoDB;"))
																		{	
																			if(mysqli_query($con,"CREATE TABLE `$mymember` ( `s_no` INT(50)  AUTO_INCREMENT , `name` TEXT  ,`email` TEXT  , `id` INT(50)  ,`mobile_no` INT(20)  , `uid` TEXT , `Fee` TEXT , `profit` TEXT ,`payu_transaction_id` TEXT ,`browser` TEXT  ,`timing` TEXT  ,`day` TEXT  ,`month` TEXT  ,`year` TEXT  ,`referer` TEXT  ,`ip_address` TEXT  ,PRIMARY KEY (`s_no`)  ) ENGINE = InnoDB;"))
																			{
																				if(mysqli_query($con,"insert into allmember(name,email,mobile_no,passwordX,browser,ip_address,fee_status,conform_email,sign_up_day,sign_up_month,sign_up_year,sign_up_time,gender,date_dob,month_dob,year_dob,uid) values ('$nameX','$emailX','$mobile_noX','$passwordX','$browser','$ip_address','0','0','$sign_up_day','$sign_up_month','$sign_up_year','$sign_up_time','$genderX','$date_dob','$month_dob','$year_dob','$uid')"))
																					{                                                 
																						$_SESSION['nameX']=$nameX;
																						$_SESSION['logintemp']=$emailX;
																						header("location: index.php");
																					}
																					else
																					{
																						echo mysql_error();
																						//header("location: sign-up.php?error_code=15");	
																					}
																			}
																				else
																				{
																					header("location: sign-up.php?error_code=16");	
																				}
																		}
																			
																		
																																			
															    }
																else
																{
                                                                             header("location: sign-up.php?error_code=20");	
															    }
															
												
											
			                    }
						        else
			                    {
											 header("location: sign-up.php?user_exist=1&error_code=27");
			                    }
                        }
					   else
	                   {
									 header("location: sign-up.php?password_error=1&error_code=28");
	                   }
	                }
				    else
	                {
								 header("location: sign-up.php?errorpasswordsecurity=1&error_code=29");
	                }	
				}
			   else
	           {
							 header("location: sign-up.php?mobile_error=1&error_code=30");
	           }
			}
		    else
	        {
						 header("location: sign-up.php?email_error=1&error_code=31");
	        }	
	}
	else
	{
				 header("location: sign-up.php?name_error=1&error_code=32");
	}
}
else
{
			header("location: sign-up.php?unknowngender=".$genderX."&error_code=33");
}
}
}
else
{
			header("location: sign-up.php?error_code=34");
}

?>