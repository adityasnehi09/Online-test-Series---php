<?php
require_once(__DIR__ ."/../../foot/include/function.php");
if(is_session_started()==false){ session_start(); }

ob_start();
require_once __DIR__.'/gplus-lib/vendor/autoload.php';
require_once(__DIR__."/google_det.php");

$client = new Google_Client();
$client->setClientId(CLIENT_ID);
$client->setClientSecret(CLIENT_SECRET);
$client->setRedirectUri(REDIRECT_URI);
$client->setScopes('email');

$plus = new Google_Service_Plus($client);

if (isset($_GET['code'])) {
  $client->authenticate($_GET['code']);
  $_SESSION['access_token'] = $client->getAccessToken();
  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
}

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
  $client->setAccessToken($_SESSION['access_token']);
  $me = $plus->people->get('me');

  // Get User data
 $_SESSION['google_plus_id'] = $me['id'];
  $_SESSION['third_party_name'] =  $me['displayName'];
  $_SESSION['third_party_email'] =  $me['emails'][0]['value'];
  $email =  $me['emails'][0]['value'];
  $_SESSION['third_party_profile_image_url'] = $me['image']['url'];
  $_SESSION['third_party_cover_image_url'] = $me['cover']['coverPhoto']['url'];
  $_SESSION['google_plus_profile_url'] = $me['url'];
  
  
  
} else {
  // get the login url   
  $authUrl = $client->createAuthUrl();
}

    if (isset($authUrl)) {
        echo "<a class='login' href='" . $authUrl . "'><img src='/social/Google-Search-icon.png' height='50px'/></a>";
    }
    ?>
