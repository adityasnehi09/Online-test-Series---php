
<?php
const CLIENT_ID = '678565179904-ghvjf4qcm32c10s6c72of012vn48dsoi.apps.googleusercontent.com';
const CLIENT_SECRET = 'z9ktLmo1ME4lcm8uB1P-RnnS';
const REDIRECT_URI = 'http://www.indotufan.com/account/google';
?>