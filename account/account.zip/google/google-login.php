<?php
/*  GOOGLE LOGIN BASIC - Tutorial
 *  file            - index.php
 *  Developer       - Krishna Teja G S
 *  Website         - http://packetcode.com/apps/google-login/
 *  Date            - 28th Aug 2015
 *  license         - GNU General Public License version 2 or later
*/

// REQUIREMENTS - PHP v5.3 or later
// Note: The PHP client library requires that PHP has curl extensions configured. 

/*
 * DEFINITIONS
 *
 * load the autoload file
 * define the constants client id,secret and redirect url
 * start the session
 */
require_once __DIR__.'/gplus-lib/vendor/autoload.php';

const CLIENT_ID = '678565179904-ghvjf4qcm32c10s6c72of012vn48dsoi.apps.googleusercontent.com';
const CLIENT_SECRET = 'z9ktLmo1ME4lcm8uB1P-RnnS';
const REDIRECT_URI = 'http://www.indotufan.com/login/google-login.php';

session_start();

/* 
 * INITIALIZATION
 *
 * Create a google client object
 * set the id,secret and redirect uri
 * set the scope variables if required
 * create google plus object
 */
$client = new Google_Client();
$client->setClientId(CLIENT_ID);
$client->setClientSecret(CLIENT_SECRET);
$client->setRedirectUri(REDIRECT_URI);
$client->setScopes('email');

$plus = new Google_Service_Plus($client);

/*
 * PROCESS
 *
 * A. Pre-check for logout
 * B. Authentication and Access token
 * C. Retrive Data
 */

/* 
 * A. PRE-CHECK FOR LOGOUT
 * 
 * Unset the session variable in order to logout if already logged in    
 */
if (isset($_REQUEST['logout'])) {
   session_unset();
}

/* 
 * B. AUTHORIZATION AND ACCESS TOKEN
 *
 * If the request is a return url from the google server then
 *  1. authenticate code
 *  2. get the access token and store in session
 *  3. redirect to same url to eleminate the url varaibles sent by google
 */
if (isset($_GET['code'])) {
  $client->authenticate($_GET['code']);
  $_SESSION['access_token'] = $client->getAccessToken();
  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
}

/* 
 * C. RETRIVE DATA
 * 
 * If access token if available in session 
 * load it to the client object and access the required profile data
 */
if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
  $client->setAccessToken($_SESSION['access_token']);
  $me = $plus->people->get('me');
   // Get User data
  $id = $me['id'];
  $name =  $me['displayName'];
  $email =  $me['emails'][0]['value'];
  $_SESSION['email_third_party']=$email;
  $profile_image_url = $me['image']['url'];
  $cover_image_url = $me['cover']['coverPhoto']['url'];
  $profile_url = $me['url'];
  $_SESSION['verificationcodematch']=1;
require_once("../welcome.php");
$sql=mysqli_query($con,"select email from allmember where email='$idP'");
if(mysqli_num_rows($sql)==0)
{
	?>
	<form class="form"role="form"action="google-sign-up-verify.php"method="post"id="submitForm">
            <div class="form-group">
              <label for="username">Name</label>
			  <span class="pull-right"> <?php
										if(isset($_GET['name_error']))
										{ 
											echo "<b class='red-color'>Please Enter valid Name </b></b>";
											?>
											<style>
											#name{
												border :1px solid red;
										}
									</style>
									<?php
									}
									?></span>
			  
			  <input type="text" class="form-control input-lg"name="username"id="username" placeholder="Your Name"value="<?php echo $name; ?>"required>
            </div>
			<div class="form-group">
            <label for="useremail">Email</label>
			<span class="pull-right"><?php
									if(isset($_GET['email_error']))
									{
										echo "<b class='red-color'>Please Enter valid Email Id</b>";
										?>
										<style>
										#email{
											border :1px solid red;
										}
										</style>
										<?php
									}
									?></span>
			
			<input type="email" class="form-control input-lg" placeholder="Email"value="<?php echo $email; ?>" disabled required>
            </div>
						<div class="form-group">
             <label for="usermobile_no">Mobile Number</label>
			 <span class="pull-right">
																			<?php
										if(isset($_GET['mobile_error']))
										{
											echo "<b class='red-color'>Please Enter valid 10 digit Mobile Number</b>";
											?>
											<style>
											#mobile_no{
												border :1px solid red;
											}
											</style>
											<?php
										}
										?></span><input type="number" class="form-control input-lg"name="usermobile_no" id="usermobile_no"placeholder="Mobile Number"required>
            </div>
			<div class="form-group">
              <label for="userpassword">Create Password</label>
			  <span class="pull-right">	 
																					<?php
								if(isset($_GET['password_error']))
								{
									echo "<b class='red-color'>Password must be greater then 6 digit</b>";
									?>
									<style>
									#password{
										border :1px solid red;
									}
									</style>
									<?php
								}
								if(isset($_GET['errorpasswordsecurity']))
								{
									echo "<b class='red-color'>Due to security you cannot use \" \' \> \< </b>";
									?>
									<style>
										#password{
											border :1px solid red;
										}
									</style>
									<?php
								}?></span><input type="password" class="form-control input-lg"name="userpassword" placeholder="Create Password"id="userpassword"required>
            </div>
			<div class="form-group">
			<label for="userdob">Date Of Birth</label>
			<div class="row">
			<div class="col-sm-4">
			<select class="form-control"name="date_dob" required>
			<option value="">Date</option>
			<?php for($x=1;$x<32;$x++){?><option value="<?php echo $x; ?>"><?php echo $x; ?></option> <?php } ?>
			</select>
			  
			</div>
					
<div class="col-sm-4">
			 <select class="form-control"name="month_dob" required>
			<option value="">Month</option>
			<?php for($x=1;$x<13;$x++){?><option value="<?php echo $x; ?>"><?php echo $x; ?></option> <?php } ?>
			</select>
			</div>
					
<div class="col-sm-4">
			<select class="form-control"name="year_dob" required>
			<option value="">Year</option>
			<?php for($x=2016;$x>1950;$x--){?><option value="<?php echo $x; ?>"><?php echo $x; ?></option> <?php } ?>
			</select>
			</div>
										
			
            </div>
            </div>
			  <div class="form-group">
            						  <label for="usergender"> Gender </label> &nbsp;&nbsp;&nbsp; Male <input type="radio" value="male" name="usergender"required> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Female <input type="radio" value="female" name="usergender"required>
            </div>
			 <div class="form-group">
<input type="checkbox" id="checkbocterms" name="loginpassword"required> I accept all the <a href="terms.php"target="_blank">terms and condition </a>
            </div>
            <div class="form-group">
              <input type="submit" class="btn btn-primary btn-lg btn-block"name="google_sign_submit"value="Sign Up"id="signupsubmit"/>
            </div>
          </form>
	
	
	
	
	
	<?php
}
 

} else {
  // get the login url   
  $authUrl = $client->createAuthUrl();
}


?>

<!-- HTML CODE with Embeded PHP-->
<div>
    <?php
    /*
     * If login url is there then display login button
     * else print the retieved data
    */
    if (isset($authUrl)) {
        echo "<a class='login' href='" . $authUrl . "'><img src='gplus-lib/signin_button.png' height='50px'/></a>";
    } else {
        print "ID: {$id} <br>";
        print "Name: {$name} <br>";
        print "Email: {$email } <br>";
        print "Image : {$profile_image_url} <br>";
        print "Cover  :{$cover_image_url} <br>";
        print "Url: {$profile_url} <br><br>";
        echo "<a class='logout' href='?logout'><button>Logout</button></a>";
    }
    ?>
</div>

