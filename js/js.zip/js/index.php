go to <a href="http://nightbird.in">nightbird.in</a>

<?php

header("location: http://nightbird.in");


?>