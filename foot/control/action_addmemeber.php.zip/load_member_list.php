<?php 
    
include_once 'session.php'; 

if(empty($_POST['search'])){
    $sqlQuery  = mysql_query("SELECT * FROM `member` order by id desc");
}else{
    $sr = $_POST['search']; 
    $sqlQuery  = mysql_query("SELECT * FROM `member`  WHERE `username`='$sr' order by id desc");
}

 

$count  = mysql_num_rows($sqlQuery);


$adjacents = 2;
$records_per_page = 10;

$page = (int) (isset($_POST['page_id']) ? $_POST['page_id'] : 1);
$page = ($page == 0 ? 1 : $page);
$start = ($page-1) * $records_per_page;

$next = $page + 1;
$prev = $page - 1;
$last_page = ceil($count/$records_per_page);
$second_last = $last_page - 1;

$pagination = pagenation($adjacents,$records_per_page,$page,$start,$next,$prev,$last_page,$second_last);
    
?>



<table class="table">
  <thead>
    <tr>
    	<th>Name</th>
      	<th>Username</th> 
      	<th>Contact</th>
      	<th>Email</th>
      	<th>Balance</th>
		<!--<th>Currency</th>-->
<th>Status</th>
		<th style="width: 15em;"></th>		
    </tr>
  </thead>
  <tbody>
  
  
  <?php 
  
  if(empty($_POST['search'])){
      $query = Query("SELECT * FROM `member` order by id desc LIMIT $start, $records_per_page");
  }else{
      $sr = $_POST['search'];
      $query = Query("SELECT * FROM `member`  WHERE `username` = '$sr' order by id desc LIMIT $start, $records_per_page");
  } 
  

$status = array('0' => '<span class="label label-success">Active</span>','1' => '<span class="label label-danger">Inactive</span>');
$i=1;
    while($row = QueryArray($query)){
       echo '<tr> 
<td>'.$row['fname'].' '.$row['lname'].'</td>       
<td>'.$row['username'].'</td>
<td>'.$row['mobile'].'</td>  
<td>'.$row['email'].'</td> 
<td>'.$row['balance'].'</td>';
//echo (($row['currency'] == 'USD') ? '<td>CREDIT</td>' : '<td>'.$row['currency'].'</td>');
echo '<td>'.$status[$row['status']].'</td>
<td>
<a target="_blank" href="status_update.php?id='.$row['id'].'" title="Active/Inactive"><i class="fa fa-retweet"></i></a>&nbsp;&nbsp;			
<a target="_blank" href="password_update.php?id='.$row['id'].'"><i class="fa fa-key"></i></a>&nbsp;&nbsp;
			<!--<a target="_blank" href="profile_view.php?id='.$row['id'].'"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;-->
			<a target="_blank" href="changenotice_two.php?id='.$row['id'].'"><i class="fa fa-envelope"></i></a>&nbsp;&nbsp;
			<a target="_blank" href="changenotice_three.php?id='.$row['id'].'"><i class="fa fa-envelope-o"></i></a>&nbsp;&nbsp;
			
			<a target="_blank" href="profile_edit.php?id='.$row['id'].'"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;				
            <a target="_blank" href="user_balance_history.php?id='.$row['id'].'"><i class="fa fa-history"></i></a>&nbsp;&nbsp; 
</td>
</tr>';
    }
   
  ?> 
  </tbody>
</table>
<?php echo $pagination;?>